<?php
session_start();
require_once 'config.php';

// Check if user is verified
if (!isset($_SESSION['verified_user_id'])) {
    header('Location: search-create.php');
    exit();
}

$cv_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['verified_user_id'];

// Verify this CV belongs to the user
if ($cv_id !== $user_id) {
    echo "<script>alert('Unauthorized access'); window.location.href='dashboard.php';</script>";
    exit();
}

$conn = getDBConnection();
$conn->begin_transaction();

try {
    // Delete all related data
    $tables = ['career_objectives', 'education', 'work_experience', 'skills', 'interests', 'reference'];
    
    foreach ($tables as $table) {
        $sql = "DELETE FROM $table WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Delete personal information
    $sql = "DELETE FROM personal_information WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cv_id);
    $stmt->execute();
    $stmt->close();
    
    $conn->commit();
    
    // Logout user
    session_destroy();
    echo "<script>alert('CV deleted successfully'); window.location.href='search-create.php';</script>";
    
} catch (Exception $e) {
    $conn->rollback();
    echo "<script>alert('Error deleting CV: " . $e->getMessage() . "'); window.location.href='dashboard.php';</script>";
}

closeDBConnection($conn);
?>
