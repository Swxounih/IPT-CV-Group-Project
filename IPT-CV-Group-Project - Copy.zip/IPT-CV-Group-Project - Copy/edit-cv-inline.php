<?php
session_start();
require_once 'config.php';

// Check if user is verified
if (!isset($_SESSION['verified_user_id'])) {
    header('Location: search-create.php');
    exit();
}

// Get CV ID from URL
$cv_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['verified_user_id'];

// Verify this CV belongs to the user
if ($cv_id !== $user_id) {
    echo "<script>alert('Unauthorized access'); window.location.href='dashboard.php';</script>";
    exit();
}

$conn = getDBConnection();
$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();

        // Update personal information
        $sql = "UPDATE personal_information SET 
                given_name = ?, middle_name = ?, surname = ?, extension = ?,
                gender = ?, birthdate = ?, birthplace = ?, civil_status = ?,
                email = ?, phone = ?, address = ?, website = ?, updated_at = NOW()
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssssi",
            $_POST['given_name'], $_POST['middle_name'], $_POST['surname'], $_POST['extension'],
            $_POST['gender'], $_POST['birthdate'], $_POST['birthplace'], $_POST['civil_status'],
            $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['website'], $cv_id);
        $stmt->execute();
        $stmt->close();

        // Update career objective
        $sql = "DELETE FROM career_objectives WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (!empty($_POST['objective'])) {
            $sql = "INSERT INTO career_objectives (personal_info_id, objective) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $cv_id, $_POST['objective']);
            $stmt->execute();
            $stmt->close();
        }

        // Handle education entries
        $sql = "DELETE FROM education WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (isset($_POST['education']) && is_array($_POST['education'])) {
            $sql = "INSERT INTO education (personal_info_id, degree, institution, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            foreach ($_POST['education'] as $edu) {
                if (!empty($edu['degree']) || !empty($edu['institution'])) {
                    $stmt->bind_param("isssss", $cv_id, $edu['degree'], $edu['institution'], 
                                     $edu['start_date'] ?? null, $edu['end_date'] ?? null, $edu['description'] ?? null);
                    $stmt->execute();
                }
            }
            $stmt->close();
        }

        // Handle work experience
        $sql = "DELETE FROM work_experience WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (isset($_POST['work_experience']) && is_array($_POST['work_experience'])) {
            $sql = "INSERT INTO work_experience (personal_info_id, position, company, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            foreach ($_POST['work_experience'] as $work) {
                if (!empty($work['position']) || !empty($work['company'])) {
                    $stmt->bind_param("isssss", $cv_id, $work['position'], $work['company'], 
                                     $work['start_date'] ?? null, $work['end_date'] ?? null, $work['description'] ?? null);
                    $stmt->execute();
                }
            }
            $stmt->close();
        }

        // Handle skills
        $sql = "DELETE FROM skills WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (isset($_POST['skills']) && is_array($_POST['skills'])) {
            $sql = "INSERT INTO skills (personal_info_id, skill_name, proficiency) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            foreach ($_POST['skills'] as $skill) {
                if (!empty($skill['skill_name'])) {
                    $stmt->bind_param("iss", $cv_id, $skill['skill_name'], $skill['proficiency'] ?? 'Intermediate');
                    $stmt->execute();
                }
            }
            $stmt->close();
        }

        // Handle interests
        $sql = "DELETE FROM interests WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (!empty($_POST['interests'])) {
            $sql = "INSERT INTO interests (personal_info_id, interests) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $cv_id, $_POST['interests']);
            $stmt->execute();
            $stmt->close();
        }

        // Handle references
        $sql = "DELETE FROM reference WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();
        $stmt->close();

        if (isset($_POST['references']) && is_array($_POST['references'])) {
            $sql = "INSERT INTO reference (personal_info_id, name, position, organization, email, phone) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            foreach ($_POST['references'] as $ref) {
                if (!empty($ref['name'])) {
                    $stmt->bind_param("isssss", $cv_id, $ref['name'], $ref['position'] ?? null, 
                                     $ref['organization'] ?? null, $ref['email'] ?? null, $ref['phone'] ?? null);
                    $stmt->execute();
                }
            }
            $stmt->close();
        }

        $conn->commit();
        $success_message = "CV updated successfully!";
    } catch (Exception $e) {
        $conn->rollback();
        $error_message = "Error updating CV: " . $e->getMessage();
    }
}

// Load existing CV data
$sql = "SELECT * FROM personal_information WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$personal_info = $result->fetch_assoc();
$stmt->close();

// Load objective
$sql = "SELECT objective FROM career_objectives WHERE personal_info_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$objective = $result->num_rows > 0 ? $result->fetch_assoc()['objective'] : '';
$stmt->close();

// Load education
$sql = "SELECT * FROM education WHERE personal_info_id = ? ORDER BY start_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$education = [];
while ($row = $result->fetch_assoc()) {
    $education[] = $row;
}
$stmt->close();

// Load work experience
$sql = "SELECT * FROM work_experience WHERE personal_info_id = ? ORDER BY start_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$work_experience = [];
while ($row = $result->fetch_assoc()) {
    $work_experience[] = $row;
}
$stmt->close();

// Load skills
$sql = "SELECT * FROM skills WHERE personal_info_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$skills = [];
while ($row = $result->fetch_assoc()) {
    $skills[] = $row;
}
$stmt->close();

// Load interests
$sql = "SELECT interests FROM interests WHERE personal_info_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$interests = $result->num_rows > 0 ? $result->fetch_assoc()['interests'] : '';
$stmt->close();

// Load references
$sql = "SELECT * FROM reference WHERE personal_info_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$result = $stmt->get_result();
$references = [];
while ($row = $result->fetch_assoc()) {
    $references[] = $row;
}
$stmt->close();

closeDBConnection($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit CV - CV Builder</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .header p {
            opacity: 0.9;
        }

        .content {
            padding: 40px;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }

        .section {
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #e2e8f0;
        }

        .section:last-of-type {
            border-bottom: none;
        }

        .section-title {
            font-size: 22px;
            color: #1e293b;
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
            display: inline-block;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-row.full {
            grid-template-columns: 1fr;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: #1e293b;
            font-size: 14px;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-family: inherit;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .entry-item {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border: 1px solid #e2e8f0;
            position: relative;
        }

        .entry-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #cbd5e1;
        }

        .entry-header h4 {
            color: #1e293b;
            font-size: 16px;
        }

        .entry-number {
            background: #667eea;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
        }

        .btn-remove-entry {
            background: #ef4444;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-remove-entry:hover {
            background: #dc2626;
        }

        .add-button {
            background: #10b981;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
            margin-bottom: 20px;
        }

        .add-button:hover {
            background: #059669;
        }

        .hidden {
            display: none;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid #e2e8f0;
        }

        .btn-save {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .btn-cancel {
            background: #64748b;
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn-cancel:hover {
            background: #475569;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }

            .content {
                padding: 20px;
            }

            .header {
                padding: 20px;
            }

            .header h1 {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✏️ Edit Your CV</h1>
            <p>Update your resume information</p>
        </div>

        <form method="POST" class="content">
            <?php if ($success_message): ?>
                <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <!-- Personal Information Section -->
            <div class="section">
                <div class="section-title">📋 Personal Information</div>
                <div class="form-row">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="given_name" value="<?php echo htmlspecialchars($personal_info['given_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="surname" value="<?php echo htmlspecialchars($personal_info['surname'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" value="<?php echo htmlspecialchars($personal_info['middle_name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Extension (Jr., Sr., etc.)</label>
                        <input type="text" name="extension" value="<?php echo htmlspecialchars($personal_info['extension'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($personal_info['email'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Phone *</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($personal_info['phone'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row full">
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($personal_info['address'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Website/Portfolio</label>
                        <input type="url" name="website" value="<?php echo htmlspecialchars($personal_info['website'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select name="gender">
                            <option value="">Select Gender</option>
                            <option value="Male" <?php echo ($personal_info['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo ($personal_info['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo ($personal_info['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                            <option value="Prefer not to say" <?php echo ($personal_info['gender'] ?? '') === 'Prefer not to say' ? 'selected' : ''; ?>>Prefer not to say</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Birth Date</label>
                        <input type="date" name="birthdate" value="<?php echo htmlspecialchars($personal_info['birthdate'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Birth Place</label>
                        <input type="text" name="birthplace" value="<?php echo htmlspecialchars($personal_info['birthplace'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Civil Status</label>
                        <select name="civil_status">
                            <option value="">Select Status</option>
                            <option value="Single" <?php echo ($personal_info['civil_status'] ?? '') === 'Single' ? 'selected' : ''; ?>>Single</option>
                            <option value="Married" <?php echo ($personal_info['civil_status'] ?? '') === 'Married' ? 'selected' : ''; ?>>Married</option>
                            <option value="Divorced" <?php echo ($personal_info['civil_status'] ?? '') === 'Divorced' ? 'selected' : ''; ?>>Divorced</option>
                            <option value="Widowed" <?php echo ($personal_info['civil_status'] ?? '') === 'Widowed' ? 'selected' : ''; ?>>Widowed</option>
                        </select>
                    </div>
                    <div class="form-group"></div>
                </div>
            </div>

            <!-- Career Objective Section -->
            <div class="section">
                <div class="section-title">🎯 Career Objective</div>
                <div class="form-group full">
                    <label>Professional Summary</label>
                    <textarea name="objective" placeholder="Write a brief summary of your career goals and professional highlight..."><?php echo htmlspecialchars($objective ?? ''); ?></textarea>
                </div>
            </div>

            <!-- Education Section -->
            <div class="section">
                <div class="section-title">🎓 Education</div>
                <div id="education-container">
                    <?php if (!empty($education)): ?>
                        <?php foreach ($education as $index => $edu): ?>
                            <div class="entry-item education-item">
                                <div class="entry-header">
                                    <div style="display: flex; align-items: center; gap: 15px;">
                                        <span class="entry-number"><?php echo $index + 1; ?></span>
                                        <h4><?php echo htmlspecialchars($edu['degree'] ?? ''); ?> - <?php echo htmlspecialchars($edu['institution'] ?? ''); ?></h4>
                                    </div>
                                    <button type="button" class="btn-remove-entry" onclick="removeEducation(this)">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Degree/Certification</label>
                                        <input type="text" name="education[<?php echo $index; ?>][degree]" value="<?php echo htmlspecialchars($edu['degree'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Institution</label>
                                        <input type="text" name="education[<?php echo $index; ?>][institution]" value="<?php echo htmlspecialchars($edu['institution'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Start Date</label>
                                        <input type="date" name="education[<?php echo $index; ?>][start_date]" value="<?php echo htmlspecialchars($edu['start_date'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>End Date</label>
                                        <input type="date" name="education[<?php echo $index; ?>][end_date]" value="<?php echo htmlspecialchars($edu['end_date'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row full">
                                    <div class="form-group">
                                        <label>Description/Honors</label>
                                        <textarea name="education[<?php echo $index; ?>][description]"><?php echo htmlspecialchars($edu['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="add-button" onclick="addEducation()">+ Add Education</button>
            </div>

            <!-- Work Experience Section -->
            <div class="section">
                <div class="section-title">💼 Work Experience</div>
                <div id="experience-container">
                    <?php if (!empty($work_experience)): ?>
                        <?php foreach ($work_experience as $index => $work): ?>
                            <div class="entry-item work-item">
                                <div class="entry-header">
                                    <div style="display: flex; align-items: center; gap: 15px;">
                                        <span class="entry-number"><?php echo $index + 1; ?></span>
                                        <h4><?php echo htmlspecialchars($work['position'] ?? ''); ?> - <?php echo htmlspecialchars($work['company'] ?? ''); ?></h4>
                                    </div>
                                    <button type="button" class="btn-remove-entry" onclick="removeExperience(this)">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Position</label>
                                        <input type="text" name="work_experience[<?php echo $index; ?>][position]" value="<?php echo htmlspecialchars($work['job_title'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Company</label>
                                        <input type="text" name="work_experience[<?php echo $index; ?>][company]" value="<?php echo htmlspecialchars($work['company'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Start Date</label>
                                        <input type="date" name="work_experience[<?php echo $index; ?>][start_date]" value="<?php echo htmlspecialchars($work['start_date'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>End Date</label>
                                        <input type="date" name="work_experience[<?php echo $index; ?>][end_date]" value="<?php echo htmlspecialchars($work['end_date'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row full">
                                    <div class="form-group">
                                        <label>Job Description/Achievements</label>
                                        <textarea name="work_experience[<?php echo $index; ?>][description]"><?php echo htmlspecialchars($work['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="add-button" onclick="addExperience()">+ Add Work Experience</button>
            </div>

            <!-- Skills Section -->
            <div class="section">
                <div class="section-title">⚡ Skills</div>
                <div id="skills-container">
                    <?php if (!empty($skills)): ?>
                        <?php foreach ($skills as $index => $skill): ?>
                            <div class="entry-item skill-item">
                                <div class="entry-header">
                                    <div style="display: flex; align-items: center; gap: 15px;">
                                        <span class="entry-number"><?php echo $index + 1; ?></span>
                                        <h4><?php echo htmlspecialchars($skill['skill_name'] ?? ''); ?></h4>
                                    </div>
                                    <button type="button" class="btn-remove-entry" onclick="removeSkill(this)">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Skill Name</label>
                                        <input type="text" name="skills[<?php echo $index; ?>][skill_name]" value="<?php echo htmlspecialchars($skill['skill_name'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Proficiency Level</label>
                                        <select name="skills[<?php echo $index; ?>][proficiency]">
                                            <option value="Beginner" <?php echo ($skill['proficiency'] ?? '') === 'Beginner' ? 'selected' : ''; ?>>Beginner</option>
                                            <option value="Intermediate" <?php echo ($skill['proficiency'] ?? '') === 'Intermediate' ? 'selected' : ''; ?>>Intermediate</option>
                                            <option value="Advanced" <?php echo ($skill['proficiency'] ?? '') === 'Advanced' ? 'selected' : ''; ?>>Advanced</option>
                                            <option value="Expert" <?php echo ($skill['proficiency'] ?? '') === 'Expert' ? 'selected' : ''; ?>>Expert</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="add-button" onclick="addSkill()">+ Add Skill</button>
            </div>

            <!-- Interests Section -->
            <div class="section">
                <div class="section-title">🎨 Interests & Hobbies</div>
                <div class="form-group full">
                    <label>Tell us about your interests</label>
                    <textarea name="interests" placeholder="E.g., Reading, Photography, Traveling, Gaming, etc..."><?php echo htmlspecialchars($interests ?? ''); ?></textarea>
                </div>
            </div>

            <!-- References Section -->
            <div class="section">
                <div class="section-title">👥 References</div>
                <div id="references-container">
                    <?php if (!empty($references)): ?>
                        <?php foreach ($references as $index => $ref): ?>
                            <div class="entry-item reference-item">
                                <div class="entry-header">
                                    <div style="display: flex; align-items: center; gap: 15px;">
                                        <span class="entry-number"><?php echo $index + 1; ?></span>
                                        <h4><?php echo htmlspecialchars($ref['name'] ?? ''); ?></h4>
                                    </div>
                                    <button type="button" class="btn-remove-entry" onclick="removeReference(this)">Remove</button>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Full Name</label>
                                        <input type="text" name="references[<?php echo $index; ?>][name]" value="<?php echo htmlspecialchars($ref['name'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Position/Title</label>
                                        <input type="text" name="references[<?php echo $index; ?>][position]" value="<?php echo htmlspecialchars($ref['position'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Organization</label>
                                        <input type="text" name="references[<?php echo $index; ?>][organization]" value="<?php echo htmlspecialchars($ref['organization'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="references[<?php echo $index; ?>][email]" value="<?php echo htmlspecialchars($ref['email'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="tel" name="references[<?php echo $index; ?>][phone]" value="<?php echo htmlspecialchars($ref['phone'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="add-button" onclick="addReference()">+ Add Reference</button>
            </div>

            <!-- Form Actions -->
            <div class="form-actions">
                <button type="submit" class="btn-save">💾 Save Changes</button>
                <button type="button" class="btn-cancel" onclick="window.location.href='dashboard.php'">Cancel</button>
            </div>
        </form>
    </div>

    <script>
        let educationCount = <?php echo count($education); ?>;
        let experienceCount = <?php echo count($work_experience); ?>;
        let skillsCount = <?php echo count($skills); ?>;
        let referencesCount = <?php echo count($references); ?>;

        function addEducation() {
            const container = document.getElementById('education-container');
            const html = `
                <div class="entry-item education-item">
                    <div class="entry-header">
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span class="entry-number">${educationCount + 1}</span>
                            <h4>New Education Entry</h4>
                        </div>
                        <button type="button" class="btn-remove-entry" onclick="removeEducation(this)">Remove</button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Degree/Certification</label>
                            <input type="text" name="education[${educationCount}][degree]">
                        </div>
                        <div class="form-group">
                            <label>Institution</label>
                            <input type="text" name="education[${educationCount}][institution]">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="date" name="education[${educationCount}][start_date]">
                        </div>
                        <div class="form-group">
                            <label>End Date</label>
                            <input type="date" name="education[${educationCount}][end_date]">
                        </div>
                    </div>
                    <div class="form-row full">
                        <div class="form-group">
                            <label>Description/Honors</label>
                            <textarea name="education[${educationCount}][description]"></textarea>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
            educationCount++;
        }

        function removeEducation(btn) {
            btn.closest('.education-item').remove();
        }

        function addExperience() {
            const container = document.getElementById('experience-container');
            const html = `
                <div class="entry-item work-item">
                    <div class="entry-header">
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span class="entry-number">${experienceCount + 1}</span>
                            <h4>New Work Experience</h4>
                        </div>
                        <button type="button" class="btn-remove-entry" onclick="removeExperience(this)">Remove</button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Position</label>
                            <input type="text" name="work_experience[${experienceCount}][position]">
                        </div>
                        <div class="form-group">
                            <label>Company</label>
                            <input type="text" name="work_experience[${experienceCount}][company]">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="date" name="work_experience[${experienceCount}][start_date]">
                        </div>
                        <div class="form-group">
                            <label>End Date</label>
                            <input type="date" name="work_experience[${experienceCount}][end_date]">
                        </div>
                    </div>
                    <div class="form-row full">
                        <div class="form-group">
                            <label>Job Description/Achievements</label>
                            <textarea name="work_experience[${experienceCount}][description]"></textarea>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
            experienceCount++;
        }

        function removeExperience(btn) {
            btn.closest('.work-item').remove();
        }

        function addSkill() {
            const container = document.getElementById('skills-container');
            const html = `
                <div class="entry-item skill-item">
                    <div class="entry-header">
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span class="entry-number">${skillsCount + 1}</span>
                            <h4>New Skill</h4>
                        </div>
                        <button type="button" class="btn-remove-entry" onclick="removeSkill(this)">Remove</button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Skill Name</label>
                            <input type="text" name="skills[${skillsCount}][skill_name]">
                        </div>
                        <div class="form-group">
                            <label>Proficiency Level</label>
                            <select name="skills[${skillsCount}][proficiency]">
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate" selected>Intermediate</option>
                                <option value="Advanced">Advanced</option>
                                <option value="Expert">Expert</option>
                            </select>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
            skillsCount++;
        }

        function removeSkill(btn) {
            btn.closest('.skill-item').remove();
        }

        function addReference() {
            const container = document.getElementById('references-container');
            const html = `
                <div class="entry-item reference-item">
                    <div class="entry-header">
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span class="entry-number">${referencesCount + 1}</span>
                            <h4>New Reference</h4>
                        </div>
                        <button type="button" class="btn-remove-entry" onclick="removeReference(this)">Remove</button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="references[${referencesCount}][name]">
                        </div>
                        <div class="form-group">
                            <label>Position/Title</label>
                            <input type="text" name="references[${referencesCount}][position]">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Organization</label>
                            <input type="text" name="references[${referencesCount}][organization]">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="references[${referencesCount}][email]">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="tel" name="references[${referencesCount}][phone]">
                        </div>
                        <div class="form-group"></div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
            referencesCount++;
        }

        function removeReference(btn) {
            btn.closest('.reference-item').remove();
        }
    </script>
</body>
</html>
