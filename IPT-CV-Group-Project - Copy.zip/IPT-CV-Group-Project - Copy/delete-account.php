<?php
session_start();
require_once 'config.php';

// Check if user is verified
if (!isset($_SESSION['verified_user_id'])) {
    header('Location: search-create.php');
    exit();
}

$user_id = $_SESSION['verified_user_id'];

$conn = getDBConnection();
$conn->begin_transaction();

try {
    // Delete all CVs and related data for this user
    $tables = ['career_objectives', 'education', 'work_experience', 'skills', 'interests', 'reference'];
    
    foreach ($tables as $table) {
        $sql = "DELETE FROM $table WHERE personal_info_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Delete personal information (main account)
    $sql = "DELETE FROM personal_information WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();
    
    $conn->commit();
    
    // Logout user
    session_destroy();
    echo "<script>alert('Account deleted successfully. We're sorry to see you go.'); window.location.href='search-create.php';</script>";
    
} catch (Exception $e) {
    $conn->rollback();
    echo "<script>alert('Error deleting account: " . $e->getMessage() . "'); window.location.href='dashboard.php';</script>";
}

closeDBConnection($conn);
?>
