<?php
session_start();
require_once 'config.php';

// Check if user is verified
if (!isset($_SESSION['verified_user_id'])) {
    header('Location: search-create.php');
    exit();
}

// Initialize new CV session data, using existing personal_info_id
$_SESSION['resume_data'] = array(
    'personal_info_id' => $_SESSION['verified_user_id'],
    'is_additional_cv' => true,
    'objective' => '',
    'education' => array(),
    'work_experience' => array(),
    'skills' => array(),
    'interests' => '',
    'references' => array()
);

// Redirect to career objectives (skip personal info)
header('Location: career-objectives.php');
exit();
?>
